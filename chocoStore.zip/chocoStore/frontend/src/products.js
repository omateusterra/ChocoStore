import limao from './assets/limao-trufa.jpg'

export const PRODUCTS=[
  {
    id:1,
    productName: 'trufa-limao',
    price:2.50,
    productImage: limao
  },
  {
    id:2,
    productName: 'trufa-limao',
    price:2.50,
    productImage: limao
  },
  {
    id:3,
    productName: 'trufa-limao',
    price:2.50,
    productImage: limao
  },
  {
    id:4,
    productName: 'trufa-limao',
    price:2.50,
    productImage: limao
  },
  {
    id:5,
    productName: 'trufa-limao',
    price:2.50,
    productImage: limao
  },
  {
    id:6,
    productName: 'trufa-limao',
    price:2.50,
    productImage: limao
  },
  {
    id:7,
    productName: 'trufa-limao',
    price:2.50,
    productImage: limao
  },
  {
    id:8,
    productName: 'trufa-limao',
    price:2.50,
    productImage: limao
  }
]